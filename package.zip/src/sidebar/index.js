import * as React from 'react';
import Box from '@mui/material/Box';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Divider from '@mui/material/Divider';
import InboxIcon from '@mui/icons-material/Inbox';
import DraftsIcon from '@mui/icons-material/Drafts';
import AcUnitIcon from '@mui/icons-material/AcUnit';
import { Checklist, Create, Error, LibraryAddCheck, Person, PostAdd, TableChartOutlined } from '@mui/icons-material';

const pages =[
    {
        title:'Blog Dashboard',
        icon:<Create sx={{height:'16px'}} />,
        status:true,
    },
    {
        title:'Blog Posts',
        icon:<LibraryAddCheck sx={{height:'16px'}} />,
        status:false,
    },
    {
        title:'Add New Post',
        icon:<PostAdd sx={{height:'16px'}} />,
        status:false,
    },
    {
        title:'Forms & Components',
        icon:<Checklist sx={{height:'16px'}} />,
        status:false,
    },
    {
        title:'Tables',
        icon:<TableChartOutlined sx={{height:'16px'}} />,
        status:false,
    },
    {
        title:'User Profile',
        icon:<Person sx={{height:'16px'}} />,
        status:false,
    },
    {
        title:'Errors',
        icon:<Error sx={{height:'16px'}} />,
        status:false,
    },
]

export default function Sidebar() {
  return (
    <Box sx={{ width: '100%', maxWidth: 360, backgroundImage: 'linear-gradient(#fff 30%,#f3f3f3 50%, #3bdcf385)',height: '800px'}}>
      <nav aria-label="main mailbox folders">
        <List>
          <ListItem>
            <ListItemButton>
              <ListItemIcon sx={{minWidth:'33px',color:'#1976d2'}}>
                <AcUnitIcon />
              </ListItemIcon>
              <ListItemText primary="Shards Dashboard" />
            </ListItemButton>
          </ListItem>
          <Divider />
          {pages.map((page,index)=>(
            <ListItem disablePadding key={index} sx={{borderBottom:'1px solid #d5dedf'}}>
                <ListItemButton>
                <ListItemIcon sx={{minWidth:'33px'}} color={page.status ? '#1976d2' :'grey'}>
                    {page.icon}
                </ListItemIcon>
                <ListItemText primary={page.title} sx={{fontSize:'14px'}}/>
                </ListItemButton>
            </ListItem>
          ))}
        </List>
      </nav>
    </Box>
  );
}