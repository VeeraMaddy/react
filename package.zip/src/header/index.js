import { Box } from '@mui/material'
import React from 'react'
import Navbar from '../navbar'
import Dashboard from '../dashboard'

export default function Header() {
  return (
    <Box>
        <Box><Navbar /></Box>
        <Box><Dashboard /></Box>
    </Box>
  )
}
