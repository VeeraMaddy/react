import * as React from 'react';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import { Card, CardContent, Grid, Typography } from '@mui/material';
import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';
import SimpleLineChart from './lineChart';
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import BasicPie from './basicpie';

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: 'center',
  color: theme.palette.text.secondary,
}));

const cards = [
  {
    title:'POSTS',
    count:'2,390',
    graph:true,
    percent:'4.7%',
  },
  {
    title:'PAGES',
    count:'182',
    graph:true,
    percent:'12.4%',
  },
  {
    title:'COMMENTS',
    count:'8,147',
    graph:false,
    percent:'3.8%',
  },
  {
    title:'USERS',
    count:'2,413',
    graph:true,
    percent:'12.4%',
  },
  {
    title:'SUBSCRIBERS',
    count:'17,281',
    graph:false,
    percent:'2.4%',
  },
]


export default function Dashboard() {
  return (
    <Box sx={{backgroundImage: 'linear-gradient( #f4f8fb 70%,#3bdcf385)',height: '100vh'}}>
      <CssBaseline />
      <Box padding={4}>
        <Typography variant='caption' sx={{fontSize:'10px',color:'grey',fontWeight:'bolder',fontFamily:'sans-serif'}}>DASHBOARD</Typography>
        <Typography variant='h5' sx={{fontWeight:'bolder',fontFamily:'sans-serif',marginBottom:'1rem'}}>Blog Overview</Typography>
        <Grid container spacing={5} columns={10} sx={{alignItems:'center'}}>
          {cards.map((item,index)=>(
            <Grid item xs={2} key={index}>
              <Card sx={{textAlign:'center'}}>
                <CardContent>
                  <Typography variant='caption'>{item.title}</Typography>
                  <Typography variant='h4'>{item.count}</Typography>
                  <Typography variant='caption' color={item.graph ? 'green' : 'red'}>
                    {item.graph ? '+' : '-'}
                    {item.percent}
                    </Typography>
                </CardContent>
              </Card>
            </Grid>
          ))}
          <Grid item xs={6}>
              <Card sx={{textAlign:'center'}}>
                  <CardContent>
                    <Typography textAlign={'left'}>User</Typography>
                    <SimpleLineChart />
                  </CardContent>
              </Card>
          </Grid>
          <Grid item xs={4}>
            <Card sx={{textAlign:'center',height:'360px'}}>
              <CardContent>
              <Typography textAlign={'left'}>Users by device</Typography>
                <BasicPie />
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Box>
    </Box>
  );
}