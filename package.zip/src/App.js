import { Box, Grid } from "@mui/material";
import Header from "./header";
import Sidebar from "./sidebar";

function App() {
  return (
    <Grid container>
      <Grid item xs={2} md={2}>
        <Box>
          <Sidebar />
        </Box>
      </Grid>
      <Grid item xs={10} md={10}>
        <Box>
          <Header />
        </Box>
      </Grid>
    </Grid>
  );
}

export default App;
